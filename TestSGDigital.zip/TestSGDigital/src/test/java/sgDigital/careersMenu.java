package sgDigital;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;		
import org.testng.annotations.Test;	
import org.testng.annotations.BeforeTest;	
import org.testng.annotations.AfterTest;

public class careersMenu {
	private WebDriver driver;	

  @Test
  //TestCase#1 - Validate new menu careers available on SG Digital home page.
  public void validateNewMenu() {	
		driver.get("https://www.sgdigital.com");  
		String title = driver.getTitle();				 
		Assert.assertTrue(title.contains("Want to work for us? Search our available roles here"));
		WebElement newMenu = driver.findElement(By.linkText("Careers"));
		 String expectedURL = "https://www.sgdigital.com/careers";
		 String actualURL = driver.getCurrentUrl();
		 newMenu.click();
		 // fetch the title of the web page and save it into a string variable
		 Assert.assertEquals(expectedURL,actualURL);
		 System.out.println("New menu Careers exist on SG Digital website.");
	}	
  
  //Test Case#2 - Validate career search options
  public class ValidateSearchCareerOptions {
		{
		WebDriver driver = new FirefoxDriver();
		//ValidateNewMenu();
		System.setProperty("webdriver.Firefox.driver", "C:\\Users\\SHEETALDABHADE\\Documents\\SeleniumJars\\geckodriver.exe");
		driver.get("https://www.sgdigital.com/Careers");
		WebElement SearchTextBox = driver.findElement(By.className("srSearchInput"));
		
		if(SearchTextBox.isDisplayed()){
				System.out.println("Element is Present");
				//Enter alphanumeric characters to search vacancies
				SearchTextBox.sendKeys("Testing");
				driver.findElement(By.className(("srSearchButton"))).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				System.out.println("Search results for Testing loaded");
				
				//Enter special characters in text box
				SearchTextBox.clear();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				SearchTextBox.sendKeys("@Testing!123");
				driver.findElement(By.className(("srSearchButton"))).click();
				try {
					wait(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Search results for Testing loaded ignoring the special characters");
				
				//Selecting location from dropdown
				Select country = new Select(driver.findElement(By.id(("facet_location"))));
				country.selectByVisibleText("Singapore");
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				System.out.println("Search results for Singapore location displayed");
				
				//User presses Enter button on keyboard
				SearchTextBox.sendKeys("Testing");
				SearchTextBox.sendKeys(Keys.RETURN);
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				System.out.println("Search results for Testing loaded");
					
				
			}  
		else {
			System.out.println("Element is Absent: Test Failed");
			}
			driver.close();
			  }

  @BeforeTest
  public void beforeTest() {
	   System.setProperty("webdriver.Firefox.driver", "C:\\Users\\SHEETALDABHADE\\Documents\\SeleniumJars\\geckodriver.exe");
	   driver = new FirefoxDriver(); 
	   String appUrl = "https://www.sgdigital.com";
	   driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	   driver.get(appUrl);
  }
  @AfterTest
  public void afterTest() {
		driver.quit();			
	}		

}
}

